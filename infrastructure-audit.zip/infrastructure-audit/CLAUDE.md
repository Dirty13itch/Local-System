# Infrastructure Audit

Produce a thorough software and OS inventory of every node in this homelab cluster. The results will be used to configure the DEV node, which is a fresh Ubuntu 24.04 install — so be detailed on toolchains, versions, driver versions, Docker configurations, and anything DEV would need to match or be compatible with.

## Nodes

| Node | IP | SSH User | OS |
|------|----|----------|-----|
| VAULT | 192.168.1.203 | root | Unraid 7.2.0 |
| Node 1 | 192.168.1.246 | unknown — discover | Ubuntu |
| Node 2 | 192.168.1.225 | unknown — discover | Ubuntu |
| DEV | 192.168.1.189 | unknown — discover | Ubuntu 24.04 (fresh) |
| DESK | local machine | N/A | Windows 11 |

Start with VAULT (SSH confirmed) and use it to help discover SSH users on the other nodes.

## Output

Write one markdown file per node to `outputs/`. Then produce a consolidated `outputs/software-inventory.md`.

## Constraints

- Read-only. Do not modify, install, or configure anything on remote systems.
- Cross-check findings against `docs/installed-hardware.md` (verified hardware inventory).
- `docs/loose-hardware.md` lists uninstalled spare parts — relevant for DEV build planning.
