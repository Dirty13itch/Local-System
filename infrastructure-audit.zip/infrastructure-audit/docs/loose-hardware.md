# Athanor Hardware Inventory — Motherboards, CPUs, GPUs, RAM

*Compiled March 1, 2026 — cross-referenced from deployed system, physical audit (Feb 15), conversation history, and owner corrections*

---

## Motherboards (11 total — 5 installed, 6 loose)

### Installed

| # | Board | Chipset | Socket | Form Factor | RAM Type | PCIe Layout | Network | Node |
|---|-------|---------|--------|-------------|----------|-------------|---------|------|
| 1 | **ASRock ROMED8-2T** | EPYC (SP3) | SP3 | SSI-EEB | DDR4 ECC RDIMM (8 DIMM) | 7× PCIe 4.0 x16 — 128 lanes total | 2× 10GbE (Intel X550) + IPMI | Node 1 |
| 2 | **Gigabyte TRX50 AERO D** | TRX50 | sTR5 | E-ATX | DDR5 RDIMM (4 DIMM) | 3× PCIe 5.0 (2× x16 + 1× x4) — 48 CPU lanes | 10GbE (Aquantia) + 2.5GbE + WiFi 7 | Node 2 |
| 3 | **ASUS ProArt X870E-Creator WiFi** | X870E | AM5 | ATX | DDR5 UDIMM (4 DIMM) | 2× PCIe 5.0 x16 (x8/x8 bifurcation) + 1× PCIe 4.0 x4 | 10GbE (Marvell) + 2.5GbE + WiFi 7 | VAULT |
| 4 | **ASUS Pro B760M-CT-CSM** | B760 | LGA1700 | Micro-ATX | DDR5 UDIMM (2 DIMM) | 1× PCIe 5.0 x16 + 1× PCIe 3.0 x1 | 2.5GbE | DESK |
| 5 | **MSI PRO X870E-P WiFi** | X870E | AM5 | ATX | DDR5 UDIMM (4 DIMM) | 1× PCIe 5.0 x16 + 3× PCIe 4.0 x4 | 2.5GbE + WiFi 7 | DEV |

### Loose

| # | Board | Chipset | Socket | Form Factor | RAM Type | PCIe Layout | Network |
|---|-------|---------|--------|-------------|----------|-------------|---------|
| 6 | **MSI Z790 MAG Tomahawk Max WiFi** | Z790 | LGA1700 | ATX | DDR5 UDIMM (4 DIMM) | 1× PCIe 5.0 x16 + 1× PCIe 4.0 x16 (x4 elec.) | 2.5GbE + WiFi 6E |
| 7 | **Gigabyte Z690 AORUS Ultra DDR5** | Z690 | LGA1700 | ATX | DDR5 UDIMM (4 DIMM) | 1× PCIe 5.0 x16 + 2× PCIe 3.0 x16 (x4 elec.) | 2.5GbE + WiFi 6E |
| 8 | **Gigabyte Z690 AORUS Elite AX DDR4** | Z690 | LGA1700 | ATX | DDR4 UDIMM (4 DIMM) | 1× PCIe 5.0 x16 + 2× PCIe 3.0 x16 (x4 elec.) | 2.5GbE + WiFi 6E |
| 9 | **Gigabyte Z390 AORUS Pro WiFi** | Z390 | LGA1151 | ATX | DDR4 UDIMM (4 DIMM) | 2× PCIe 3.0 x16 + 1× PCIe 3.0 x1 | 1GbE + WiFi |
| 10 | **Gigabyte Z370 AORUS Gaming 5** | Z370 | LGA1151 | ATX | DDR4 UDIMM (4 DIMM) | 3× PCIe 3.0 x16 + 1× PCIe 3.0 x1 | 1GbE (Killer E2500) |
| 11 | **Gigabyte B365M DS3H** | B365 | LGA1151 | Micro-ATX | DDR4 UDIMM (2 DIMM) | 1× PCIe 3.0 x16 + 1× PCIe 3.0 x1 | 1GbE |

### Compatible Loose Pairings

| CPU (loose) | Compatible Loose Boards |
|-------------|------------------------|
| i7-12700K / i5-12600K (LGA1700) | Z790 Tomahawk (DDR5), Z690 Ultra DDR5, Z690 Elite AX DDR4 |
| i7-9700K / i7-8700K (LGA1151) | Z390 Pro WiFi, Z370 Gaming 5, B365M DS3H |

---

## CPUs (9 total — 5 installed, 4 loose)

### Installed

| # | CPU | Architecture | Socket | Cores/Threads | Base/Boost | L3 Cache | TDP | Memory Support | Node |
|---|-----|-------------|--------|---------------|------------|----------|-----|----------------|------|
| 1 | **AMD EPYC 7663** | Zen 3 (Milan) | SP3 | 56C / 112T | 2.0 / 3.5 GHz | 256 MB | 240W | DDR4-3200 ECC (8-ch) | Node 1 |
| 2 | **AMD Threadripper 7960X** | Zen 4 | sTR5 | 24C / 48T | 4.2 / 5.3 GHz | 128 MB | 350W | DDR5-5200 RDIMM (4-ch) | Node 2 |
| 3 | **AMD Ryzen 9 9950X** | Zen 5 | AM5 | 16C / 32T | 4.3 / 5.7 GHz | 64 MB | 170W | DDR5-5600 UDIMM (2-ch) | VAULT |
| 4 | **Intel Core i7-13700K** | Raptor Lake | LGA1700 | 16C / 24T (8P+8E) | 3.4 / 5.4 GHz | 30 MB | 253W | DDR5-5600 / DDR4-4800 (2-ch) | DESK |
| 5 | **AMD Ryzen 9 9900X** | Zen 5 | AM5 | 12C / 24T | 4.4 / 5.6 GHz | 64 MB | 120W | DDR5-5600 UDIMM (2-ch) | DEV |

### Loose

| # | CPU | Architecture | Socket | Cores/Threads | Base/Boost | L3 Cache | TDP |
|---|-----|-------------|--------|---------------|------------|----------|-----|
| 6 | **Intel Core i7-12700K** (SRL4N) | Alder Lake | LGA1700 | 12C / 20T (8P+4E) | 3.6 / 5.0 GHz | 25 MB | 190W |
| 7 | **Intel Core i5-12600K** (SRL4T) | Alder Lake | LGA1700 | 10C / 16T (6P+4E) | 3.7 / 4.9 GHz | 20 MB | 150W |
| 8 | **Intel Core i7-9700K** (SRG15) | Coffee Lake | LGA1151 | 8C / 8T | 3.6 / 4.9 GHz | 12 MB | 95W |
| 9 | **Intel Core i7-8700K** | Coffee Lake | LGA1151 | 6C / 12T | 3.7 / 4.7 GHz | 12 MB | 95W |

### Summary

| Status | Count | Total Cores | Total Threads |
|--------|-------|-------------|---------------|
| Installed | 5 | 124 | 240 |
| Loose | 4 | 36 | 52 |
| **All Owned** | **9** | **160** | **292** |

---

## GPUs (10 total — 9 installed, 1 loose)

### Installed

| # | GPU | Architecture | VRAM | Bus | Bandwidth | TDP | Node | Role |
|---|-----|-------------|------|-----|-----------|-----|------|------|
| 1 | **RTX 5090** (PNY) | Blackwell | 32 GB GDDR7 | PCIe 5.0 x16 | 1.79 TB/s | 575W | Node 2 | Primary inference (Qwen3-14B fast) |
| 2 | **RTX 4090** (ASUS TUF) | Ada Lovelace | 24 GB GDDR6X | PCIe 4.0 x16 | 1.01 TB/s | ~450W | Node 1 | Standalone inference |
| 3 | **RTX 5070 Ti #1** (MSI Shadow) | Blackwell | 16 GB GDDR7 | PCIe 5.0 x16 | ~896 GB/s | ~300W | Node 1 | TP=4 group (Qwen3-32B-AWQ) |
| 4 | **RTX 5070 Ti #2** (MSI Shadow) | Blackwell | 16 GB GDDR7 | PCIe 5.0 x16 | ~896 GB/s | ~300W | Node 1 | TP=4 group |
| 5 | **RTX 5070 Ti #3** (Gigabyte Gaming OC) | Blackwell | 16 GB GDDR7 | PCIe 5.0 x16 | ~896 GB/s | ~300W | Node 1 | TP=4 group |
| 6 | **RTX 5070 Ti #4** (Gigabyte Gaming OC) | Blackwell | 16 GB GDDR7 | PCIe 5.0 x16 | ~896 GB/s | ~300W | Node 1 | Embed + voice (GPU4) |
| 7 | **RTX 5060 Ti** (Zotac Twin Edge SFF) | Blackwell | 16 GB GDDR7 | PCIe 5.0 x8 | ~448 GB/s | ~150W | DEV | Dev workloads, ComfyUI |
| 8 | **RTX 3060** (MSI Ventus 12GB) | Ampere | 12 GB GDDR6 | PCIe 4.0 x16 | 360 GB/s | 170W | DESK | Daily driver GPU |
| 9 | **Intel Arc A380** (ASRock ITX) | Alchemist (Xe) | 6 GB GDDR6 | PCIe 4.0 x8 | 186 GB/s | 75W | VAULT | Plex AV1/QSV transcode |

### Loose

| # | GPU | Architecture | VRAM | Bus | TDP | Notes |
|---|-----|-------------|------|-----|-----|-------|
| 10 | **RX 5700 XT** (ASUS ROG STRIX) | RDNA 1 | 8 GB GDDR6 | PCIe 4.0 x16 | 225W | Spare — no current allocation |

### Summary

| Location | GPUs | VRAM |
|----------|------|------|
| Node 1 | 4×5070Ti + 4090 | 88 GB |
| Node 2 | 5090 | 32 GB |
| DEV | 5060 Ti | 16 GB |
| DESK | 3060 | 12 GB |
| VAULT | Arc A380 | 6 GB |
| Loose | RX 5700 XT | 8 GB |
| **Total** | **10 GPUs** | **162 GB** |

Active compute VRAM (Node 1 + Node 2): **120 GB**
Total installed VRAM: **154 GB**

---

## RAM (816 GB total — 608 GB installed, 208 GB loose)

### Installed

| # | Type | Capacity | Configuration | Speed | Latency | Node | Board |
|---|------|----------|---------------|-------|---------|------|-------|
| 1 | DDR4 ECC RDIMM | **224 GB** | 7×32 GB (1 DIMM not working) | DDR4-3200 | — | Node 1 | ROMED8-2T |
| 2 | DDR5 RDIMM | **128 GB** | 4×32 GB | DDR5-5600 | CL28 | Node 2 | TRX50 AERO D |
| 3 | DDR5 UDIMM | **128 GB** | 4×32 GB or 2×64 GB | DDR5-5200–5600 | — | VAULT | ProArt X870E |
| 4 | DDR5 UDIMM | **64 GB** | 2×32 GB | DDR5-5200 | CL36 | DESK | B760M-CT-CSM |
| 5 | DDR5 UDIMM | **64 GB** | 2×32 GB | DDR5-5600 | CL40 | DEV | X870E-P WiFi |

*Node 1: 8th DIMM slot has a non-functional stick. 7×32GB = 224GB confirmed.*

### Loose (physically verified Feb 15)

| # | Type | Capacity | Configuration | Speed | Latency | Kit Model |
|---|------|----------|---------------|-------|---------|-----------|
| 6 | DDR5 UDIMM | **64 GB** | 2×32 GB | DDR5-5600 | CL40-40-40-89 | G.Skill Ripjaws S5 (F5-5600J4040D32GX2-RS5K) |
| 7 | DDR4 UDIMM | **64 GB** | 2×32 GB | DDR4-3200 | CL16-18-18-36 | Crucial Ballistix (BL32G32C16U4B.M16FB1) |
| 8 | DDR4 UDIMM | **32 GB** | 2×16 GB | DDR4-4000 | CL18-22-22-42 | G.Skill Ripjaws V (F4-4000C18D-32GVK) |
| 9 | DDR4 UDIMM | **32 GB** | 2×16 GB | DDR4-3200 | CL16-18-18-38 | G.Skill TridentZ RGB (F4-3200C16D-32GTZR) |
| 10 | DDR4 UDIMM | **16 GB** | 2×8 GB | DDR4-3200 | CL16-18-18-38 | G.Skill TridentZ RGB (F4-3200C16D-16GTZR) |

### Summary

| Category | Kits | Capacity |
|----------|------|----------|
| Installed DDR4 ECC | 1 | 224 GB |
| Installed DDR5 | 4 | 384 GB |
| **Installed Total** | **5** | **608 GB** |
| Loose DDR4 | 4 | 144 GB |
| Loose DDR5 | 1 | 64 GB |
| **Loose Total** | **5** | **208 GB** |
| **Grand Total** | **10** | **816 GB** |

### Loose RAM Notes

- **DDR5 orphan:** The 64GB DDR5-5600 kit has no compatible loose motherboard unless paired with the Z790 Tomahawk or Z690 Ultra DDR5 (both DDR5, LGA1700, loose).
- **Best loose pairing:** i7-12700K + Z790 Tomahawk + DDR5-5600 64GB kit = capable 12C/20T DDR5 utility node.
- **DDR4 pool:** 144GB across 4 kits — all compatible with Z690 Elite AX DDR4 and the LGA1151 boards.

---

## Node-to-Hardware Mapping (Quick Reference)

| Node | Role | CPU | Board | RAM | GPUs | Case |
|------|------|-----|-------|-----|------|------|
| **Node 1** | Inference + agents | EPYC 7663 (56C/112T) | ROMED8-2T | 224GB DDR4 ECC | 4×5070Ti (TP=4) + 4090 | CX4713 (4U) |
| **Node 2** | Interface + fast inference | TR 7960X (24C/48T) | TRX50 AERO D | 128GB DDR5 | 5090 | RM52 #1 (5U) |
| **VAULT** | Storage + services (Unraid) | 9950X (16C/32T) | ProArt X870E | 128GB DDR5 | Arc A380 | RM52 #2 (5U) |
| **DESK** | Daily driver (Win11) | i7-13700K (16C/24T) | ASUS Pro B760M-CT-CSM | 64GB DDR5 | RTX 3060 | NZXT H9 Flow |
| **DEV** | Linux dev (Ubuntu 24.04) | 9900X (12C/24T) | MSI X870E-P WiFi | 64GB DDR5 | RTX 5060 Ti | CX3171a (3U) |

---

## Loose Hardware Summary

| Category | Count | Details |
|----------|-------|---------|
| Motherboards | 6 | Z790 Tomahawk, Z690 Ultra DDR5, Z690 Elite AX DDR4, Z390 Pro, Z370 Gaming 5, B365M DS3H |
| CPUs | 4 | i7-12700K, i5-12600K, i7-9700K, i7-8700K |
| GPUs | 1 | RX 5700 XT 8GB |
| RAM | 5 kits | 64GB DDR5 + 144GB DDR4 = 208GB |
| NVMe | 11 | 4× Crucial T700 1TB (Gen5) + 5× Crucial P310 1TB (Gen4) + 1× 970 EVO Plus 1TB + 1× SN750 1TB = 11TB |
| PCIe Cards | 4 | 1× ASUS Hyper M.2 Gen5 (loose), 3× 10GbE NICs (X540-T2 / clones) |
| PSUs | 4 | SF1000L (1000W), ASUS ROG (1200W), RM750 (750W), EVGA 600B (600W) |
