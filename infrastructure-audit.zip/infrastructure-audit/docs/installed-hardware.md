# Installed Hardware by Node

*March 1, 2026*

---

## Node 1

| Component | Spec |
|-----------|------|
| CPU | AMD EPYC 7663 (56C/112T) |
| Cooler | Noctua NH-U9 TR4-SP3 |
| Board | ASRock ROMED8-2T (SP3, SSI-EEB) |
| RAM | 224 GB DDR4-3200 ECC RDIMM (7×32 GB) |
| GPU 0–3 | 4× RTX 5070 Ti 16 GB |
| GPU 4 | RTX 4090 24 GB |
| Storage (mobo) | 1× Samsung 990 Pro 4 TB + 1× Crucial P3 4 TB |
| Storage (Hyper M.2) | ASUS Hyper M.2 Gen5 — 1× 4 TB (model TBD) + 1× 2 TB (model TBD) + 2× Crucial P310 1 TB |
| Network | 2× 10GbE (Intel X550) + IPMI |
| PSU | MSI MEG Ai1600T (1600W) |
| Case | Sliger CX4713 (4U) |

---

## Node 2

| Component | Spec |
|-----------|------|
| CPU | AMD Threadripper 7960X (24C/48T) |
| Cooler | SilverStone XE360-TR5 360mm AIO |
| Board | Gigabyte TRX50 AERO D (sTR5, E-ATX) |
| RAM | 128 GB DDR5-5600 RDIMM (4×32 GB) |
| GPU 0 | RTX 5090 32 GB |
| GPU 1 | RTX 5060 Ti 16 GB |
| Storage | 1× 4 TB Crucial T700 (Gen5) + 2× 1 TB Crucial T700 (Gen5) |
| Network | 10GbE (Aquantia) + 2.5GbE + WiFi 7 |
| PSU | Corsair AX1600i (1600W) |
| Case | SilverStone RM52 (5U) |

---

## VAULT

| Component | Spec |
|-----------|------|
| CPU | AMD Ryzen 9 9950X (16C/32T) |
| Cooler | Asetek 836SA-M1 |
| Board | ASUS ProArt X870E-Creator WiFi (AM5, ATX) |
| RAM | 128 GB DDR5 UDIMM |
| GPU | Intel Arc A380 6 GB |
| Storage (mobo) | 4× Samsung 990 EVO Plus 1 TB + 1× Crucial P310 1 TB (NVMe) |
| Storage (Hyper M.2) | ASUS Hyper M.2 Gen5 — 4× Crucial P310 1 TB (just installed, needs reboot + bifurcation) |
| Storage (HDD) | 10-disk HDD array (180 TB raw) |
| HBA | LSI SAS9300-16i (SAS3224, PCIe 3.0 x8) |
| Network | 10GbE (Marvell) + 2.5GbE + WiFi 7 |
| PSU | Corsair RM1000e (1000W) |
| Case | SilverStone RM52 (5U) |

---

## DESK

| Component | Spec |
|-----------|------|
| CPU | Intel Core i7-13700K (16C/24T) |
| Cooler | ASUS ROG Strix 240mm AIO |
| Board | ASUS Pro B760M-CT-CSM (LGA1700, mATX) |
| RAM | 64 GB DDR5-5200 UDIMM (2×32 GB) |
| GPU | RTX 3060 12 GB |
| Storage | 1× Crucial T700 1 TB (Gen5) + 1× Crucial P310 2 TB (Gen4) |
| Network | 2.5GbE |
| PSU | Corsair RM750 (750W) |
| Case | NZXT H9 Flow |

---

## DEV

| Component | Spec |
|-----------|------|
| CPU | AMD Ryzen 9 9900X (12C/24T) |
| Cooler | Arctic Liquid Freezer III Pro 360mm AIO |
| Board | MSI PRO X870E-P WiFi (AM5, ATX) |
| RAM | 64 GB DDR5-5600 UDIMM (2×32 GB) |
| GPU | RTX 5060 Ti 16 GB (Zotac Twin Edge SFF) |
| Storage | 1× Crucial T700 1 TB (Gen5) + 1× Samsung 1 TB (Gen4) + 1× Crucial 4 TB (Gen4) |
| Network | 2.5GbE + WiFi 7 |
| PSU | Corsair SF750 (750W) |
| Case | Sliger CX3171a (3U) |

---

## Network

| Component | Spec |
|-----------|------|
| Router | Ubiquiti UniFi Dream Machine Pro |
| Switch (10GbE) | Ubiquiti USW-Pro-XG |
| Switch (1GbE PoE) | Ubiquiti USW-Pro-24-PoE |
| Modem | Calix C844G |

---

## Rack

| Component | Spec |
|-----------|------|
| Rack | APC NetShelter 24U |
| UPS 1 | APC SMT1500RM2U |
| UPS 2 | CyberPower CP1500PFCRM2U |
| PDU | Ubiquiti Power Distribution Pro |
| Patch Panels | 2× Ubiquiti Patch Panel |
| Brush Panel | Ubiquiti Brush Panel |

---

## Remote Management

| Node | Method |
|------|--------|
| Node 1 | IPMI (onboard) |
| Node 2 | JetKVM |
| VAULT | JetKVM |
| DESK | JetKVM |
| DEV | JetKVM |

---

## MOBILE

| Component | Spec |
|-----------|------|
| Model | ASUS ROG Strix G17 G713QR-ES98Q |
| CPU | AMD Ryzen 9 5900HX (8C/16T) |
| GPU | RTX 3070 Laptop 8 GB |
| RAM | 64 GB DDR4-3200 (2×32 GB) |
| Storage | 1× 1 TB NVMe (stock) + 1× Samsung 980 PRO 2 TB |
| Display | 17.3" WQHD 2560×1440 165Hz |
| Network | WiFi 6 + BT 5.1 + 1GbE |
| Battery | 90 Wh |
